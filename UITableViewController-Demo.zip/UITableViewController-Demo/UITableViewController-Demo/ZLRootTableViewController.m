//
//  ZLRootTableViewController.m
//  UITableViewController-Demo
//
//  Created by 尊旅环球游 on 2017/6/8.
//  Copyright © 2017年 chk. All rights reserved.
//

#import "ZLRootTableViewController.h"

@interface ZLRootTableViewController ()

@property (nonatomic,assign) CGPoint startContentOffset;

@property (nonatomic,assign) CGFloat duration;

@end

@implementation ZLRootTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self addGestureRecognizerForHideKeyBoard];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}
#pragma keyboard相关
- (void)keyboardWillShow:(NSNotification *)notice {
    
    if (self.startContentOffset.y > self.tableView.contentOffset.y) {
        self.startContentOffset = self.tableView.contentOffset;
    }
    NSDictionary *info = [notice userInfo];
    CGSize size = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    self.duration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey] floatValue];
    
    CGFloat keyboardY = [UIScreen mainScreen].bounds.size.height - size.height - 64;
    
    if ((self.currentTextFieldFrame.origin.y + self.currentTextFieldFrame.size.height - self.startContentOffset.y) > keyboardY) {
        [UIView animateWithDuration:self.duration animations:^{
            self.tableView.contentOffset = CGPointMake(0, (self.currentTextFieldFrame.origin.y + self.currentTextFieldFrame.size.height) - keyboardY);
        }];
    }
}

- (void)keyboardWillHide:(NSNotification *)notice {
    
    [UIView animateWithDuration:self.duration animations:^{
        self.tableView.contentOffset = self.startContentOffset;
    }];
    
}

//添加键盘收起方法
- (void)addGestureRecognizerForHideKeyBoard {
    UITapGestureRecognizer *tableViewGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tableViewTouchInSide)];
    tableViewGesture.numberOfTapsRequired = 1;
    tableViewGesture.cancelsTouchesInView = NO;
    [self.tableView addGestureRecognizer:tableViewGesture];
}

// ------tableView 上添加的自定义手势
- (void)tableViewTouchInSide{
    [self.view endEditing:YES];
}
#pragma UITableViewDelagate/UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    return nil;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [[UIView alloc] init];
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return CGFLOAT_MIN;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44;
}

#pragma 懒加载
- (UITableView *)tableView {
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:[[UIScreen mainScreen] bounds] style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, CGFLOAT_MIN)];
        _tableView.backgroundColor = [UIColor clearColor];
        [self.view addSubview:_tableView];
    }
    return _tableView;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    NSLog(@"Execution dealloc");
}

@end
