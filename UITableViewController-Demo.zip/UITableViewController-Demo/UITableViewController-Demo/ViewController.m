//
//  ViewController.m
//  UITableViewController-Demo
//
//  Created by 尊旅环球游 on 2017/6/6.
//  Copyright © 2017年 chk. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(100, 100, 100, 100);
    button.backgroundColor = [UIColor yellowColor];
    
    [button addTarget:self action:@selector(btnAction) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:button];
}

- (void)btnAction {
    Class class = NSClassFromString(@"TableViewController");
    if ([class isSubclassOfClass:[UIViewController class]]) {
        [self.navigationController pushViewController:[[class alloc] init] animated:YES];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
