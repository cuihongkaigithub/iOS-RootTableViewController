//
//  ZLRootTableViewController.h
//  UITableViewController-Demo
//
//  Created by 尊旅环球游 on 2017/6/8.
//  Copyright © 2017年 chk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZLRootTableViewController : UIViewController <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView *tableView;

@property (nonatomic,assign) CGRect currentTextFieldFrame;

@end
