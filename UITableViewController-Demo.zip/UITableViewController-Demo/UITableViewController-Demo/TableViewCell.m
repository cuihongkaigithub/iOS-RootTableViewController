//
//  TableViewCell.m
//  UITableViewController-Demo
//
//  Created by 尊旅环球游 on 2017/6/6.
//  Copyright © 2017年 chk. All rights reserved.
//

#import "TableViewCell.h"

@interface TableViewCell () <UITextFieldDelegate>

@property (nonatomic,strong) UITextField *textField;

@end

@implementation TableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setStr:(NSString *)str {
    _str = str;
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.textField.text = str;
}

- (UITextField *)textField {
    if (_textField == nil) {
        _textField = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, 100, self.contentView.frame.size.height)];
        _textField.delegate = self;
        [self.contentView addSubview:_textField];
    }
    return _textField;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if (self.action) {
        self.action(textField);
    }
}




- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
