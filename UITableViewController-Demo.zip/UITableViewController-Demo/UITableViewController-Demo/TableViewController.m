//
//  TableViewController.m
//  UITableViewController-Demo
//
//  Created by 尊旅环球游 on 2017/6/6.
//  Copyright © 2017年 chk. All rights reserved.
//

#import "TableViewController.h"
#import "TableViewCell.h"

#define weak(obj) __weak typeof(obj) Weak_##obj = obj;
#define strong(obj) \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Wshadow\"") \
__strong typeof(obj) obj = Weak_##obj; \
_Pragma("clang diagnostic pop")


static NSString *kTableViewCell = @"kTableViewCell";

@interface TableViewController ()

@end

@implementation TableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView registerClass:[TableViewCell class] forCellReuseIdentifier:kTableViewCell];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 20;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kTableViewCell forIndexPath:indexPath];
    
    cell.str = [NSString stringWithFormat:@"第%ld",indexPath.row];
    weak(self)
    cell.action = ^(UITextField *textField) {
        strong(self)
        self.currentTextFieldFrame = [textField convertRect:textField.frame toView:tableView];
    };
    
    return cell;
}






@end
